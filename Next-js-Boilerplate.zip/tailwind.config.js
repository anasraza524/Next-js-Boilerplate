/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/app/**/*.{js,jsx,ts,tsx}',
    './src/components/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#001C34',
        secondary: '#004B6D',
        base: '#ffffff',
        textPrimary: '#004B6D',
        textAccent: '#02AAB4',
        textDark: '#000000',
        textLight: '#ffffff',
      },
      backgroundImage: {
        'gradient-1': 'linear-gradient(146.34deg, #001C34 -2.98%, rgba(3, 160, 199, 0.3) 80.92%)',
        'gradient-2': 'linear-gradient(236.84deg, #001C34 16.25%, #03A0C7 180.71%)',
      },
      container: {
        center: true,
        padding: '1rem',
      },
    },
  },
  plugins: [],
};
