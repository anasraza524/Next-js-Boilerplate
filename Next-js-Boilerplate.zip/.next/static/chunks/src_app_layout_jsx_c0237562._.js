(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_06bb1863._.js",
  "static/chunks/node_modules_@clerk_shared_dist_c6e9dbbe._.js",
  "static/chunks/node_modules_swr_dist_d3931529._.js",
  "static/chunks/node_modules_@clerk_clerk-react_dist_0625452d._.js",
  "static/chunks/node_modules_next_b5b3bd8c._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_f264cf1d._.js",
  "static/chunks/src_e1145432._.js",
  "static/chunks/src_app_globals_b805903d.css"
],
    source: "dynamic"
});
