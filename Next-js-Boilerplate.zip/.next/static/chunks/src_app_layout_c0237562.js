(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_c363e534._.js",
  "static/chunks/node_modules_eb3a5a44._.js",
  "static/chunks/src_e1145432._.js",
  "static/chunks/src_app_globals_b805903d.css"
],
    source: "dynamic"
});
