import { SignIn } from '@clerk/nextjs';
import SignInViewPage from '@/features/auth/components/sign-in-view';
export default function SignInPage() {
  return <SignInViewPage stars={3000} />
}